import json
from download import download_file
from upload import upload_s3
import os


def lambda_handler(event, context):
    file = "2023-02-23-0.json.gz"
    download_res = download_file(file)
    bucket = os.environ.get("BUCKET_NAME")
    upload_res = upload_s3(download_res.content, bucket, file)

    return upload_res
    
