import os
import boto3
import requests

def get_client():
    s3_client = boto3.client("s3")

    return s3_client

def upload_s3(body, bucket, file):
    s3_client = get_client()
    upload_res = s3_client.put_object(
        Bucket=bucket, 
        Key=file,
        Body=body
    )
    return upload_res
